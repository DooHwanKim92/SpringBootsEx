package com.sbb.qna_ex_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QnaEx1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
