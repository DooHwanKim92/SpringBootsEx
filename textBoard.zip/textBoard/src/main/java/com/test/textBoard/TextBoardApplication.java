package com.test.textBoard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TextBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(TextBoardApplication.class, args);
	}

}
