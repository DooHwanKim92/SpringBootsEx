package com.test.textBoard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TextBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
